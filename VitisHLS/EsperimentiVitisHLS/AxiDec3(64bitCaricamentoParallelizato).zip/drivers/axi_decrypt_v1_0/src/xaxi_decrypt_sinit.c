// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xaxi_decrypt.h"

extern XAxi_decrypt_Config XAxi_decrypt_ConfigTable[];

#ifdef SDT
XAxi_decrypt_Config *XAxi_decrypt_LookupConfig(UINTPTR BaseAddress) {
	XAxi_decrypt_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XAxi_decrypt_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XAxi_decrypt_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XAxi_decrypt_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxi_decrypt_Initialize(XAxi_decrypt *InstancePtr, UINTPTR BaseAddress) {
	XAxi_decrypt_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxi_decrypt_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxi_decrypt_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XAxi_decrypt_Config *XAxi_decrypt_LookupConfig(u16 DeviceId) {
	XAxi_decrypt_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAXI_DECRYPT_NUM_INSTANCES; Index++) {
		if (XAxi_decrypt_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAxi_decrypt_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxi_decrypt_Initialize(XAxi_decrypt *InstancePtr, u16 DeviceId) {
	XAxi_decrypt_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxi_decrypt_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxi_decrypt_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

